# LimeSurvey LSNextcloud Plugin

Save all survey responses and their attachments automatically to a folder in your Nextcloud.

<img src="docs/images/screenshot.png" />

## Plugin Installation

### By zipfile

- Download the zip of [lates release](https://github.com/librecodecoop/LSNextcloud/releases/latest)
- Install the plugin in `Settings` > `Plugin Manager` > `Install zip`

### By repository

- Clone this repository to de LimeSurvey "plugins" directory
- Run `make all` command

## Configuring

Before all...

- Activate the plugin at the Limesurvey plugin manager (requires proper user rights for accessing the feature at the Limesurvey admin interface).

You can make a global setting or specific settings for each Survey.

### Global setting
- `Settings` > `Plugin Manager`
- click on LSNextcloud
- Configure the global settings

### In each Survey setting
- Go to the specific setting for a Survey
- Simple Plugins
- Settings for the LSNextcloud plugin 

The user and password for Nextcloud must be generated in Nextcloud under Settings > Security settings > App password, generate an app password with the name Lime Survey Nextcloud to make it easier to know what this password is from. Copy the password and use it to configure the plugin.

### TODO
- [ ] Select Questions to export in survey settings
  - [ ] I have the correct stringIDs but no way to get the names of questions (direct SQL or RemoteRPC would be possible)
  - [ ] some button to send data on click (upload to nextcloud)
- [x] Publish messages to message queue
- [ ] external programm consuming messages -> request JSON-RFC of Limesurvey to get Surveydata exported
  - -> for async processing (else need to wait for file to upload to nextcloud everytime someone sends an answer -> that way only small message needs to be sent)
  - -> message should contain surveyID (we have that one already) and maybe more configuration (fields to export, long/short/....)